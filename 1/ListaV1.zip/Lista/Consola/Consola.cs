﻿using System;

namespace ListaEnlazada
{

    internal class Consola
    {
        static void Main(string[] args)
        {
            ListaEnlazada lista = new ListaEnlazada();

            lista.Añadir(7); //HEAD
            lista.Añadir(3); 
            lista.Añadir(12);

            Console.WriteLine(lista.ToString());

            Console.WriteLine(lista.GetElement(1));
            Console.WriteLine(lista.GetElement(2));

            lista.Borrar(3);
            Console.WriteLine(lista.ToString());

            lista.Borrar(7);

            Console.WriteLine(lista.ToString());

        }
    }


}
