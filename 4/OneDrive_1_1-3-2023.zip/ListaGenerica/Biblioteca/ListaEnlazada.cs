﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace ListaEnlazada
{

    public class ListaEnlazada<T> : IEnumerable<T>
    {
        private Nodo _head;
        public uint NElements { get; private set; }

        private Nodo Head { get { return _head; } set { _head = value; } }


        public ListaEnlazada()
        {
            _head = null;
            NElements = 0;
        }
        public ListaEnlazada(Nodo nodo)
        {
            Head = nodo;
            NElements++;
        }

        public bool Añadir(T valor)
        {
            Nodo nuevoNodo = new Nodo(valor, null);

            //Si no tiene raiz
            if (Head == null)
            {
                Head = nuevoNodo;
                NElements++;
                return true;
            }
            //Si ya tenia algun nodo
            Nodo aux = Head;
            while (aux.NextNode != null)
            {
                aux = aux.NextNode;
            }
            aux.NextNode = nuevoNodo;
            NElements++;
            return true;
        }

        public bool Borrar(object valor)
        {
            //No hay raiz, no hay nodos
            if (Head == null)
                return false;

            Nodo aux = Head;
            //Nodo a buscar es la raiz
            if (Head.Value.Equals(valor))
            {
                Head = Head.NextNode;
                NElements--;
                return true;
            }

            //Si el nodo no es la raiz
            while (aux.NextNode != null)
            {
                if (aux.NextNode.Value.Equals(valor)) //Si el siguiente tiene el valor
                {
                    aux.NextNode = aux.NextNode.NextNode; //Cortamos su referencia, saltandolo
                    NElements--;
                    return true;
                }
                aux = aux.NextNode; //Seguimos buscando
            }
            //No hay nodo con ese valor
            return false;
        }

        public bool Contiene(T valor)
        {
            //No hay raiz, no hay nodos
            if (Head == null)
                return false;

            Nodo nodo = Head;
            if (nodo.Value.Equals(valor))
                return true;

            while (nodo.NextNode != null)
            {
                if (nodo.NextNode.Value.Equals(valor))
                    return true;

                nodo = nodo.NextNode;
            }
            return false;
        }

        public object GetElement(uint posicion)
        {
            //Comprobamos que existe esa posicion en la lista
            if (posicion > NElements - 1)
                //throw new ArgumentException("Fuera de rango");
                return null;

            Nodo aux = Head;
            int contador = 0; //Contador de posicion

            while (posicion > contador && aux.NextNode != null)
            {
                aux = aux.NextNode;

                contador++;
            }

            return aux.Value;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Lista: ");

            if (NElements <= 0)
                return "No hay Nodos.";
            Nodo aux = Head;

            int contador = 0;
            while (contador < NElements)
            {
                sb.Append(aux.ToString());
                aux = aux.NextNode;
                contador++;
            }
            return sb.ToString();
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new ListaIEnumerator(this);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public class ListaIEnumerator : IEnumerator<T>
        {
            private Nodo _head;
            public uint NElements { get; private set; }

            private Nodo _actual;

            private Nodo Head { get { return _head; } set { _head = value; } }

            public T Current
            {
                get { return _actual.Value; }
            }

            object IEnumerator.Current {
                get {
                    return _actual.Value; 
                }
            }

            public ListaIEnumerator(ListaEnlazada<T> lista) { 
                this.Head = lista.Head;
                this.NElements = lista.NElements;
            }

            public bool MoveNext()
            {
                if(_actual.NextNode == null)
                    return false;
                _actual = _actual.NextNode;
                return true;
            }

            public void Reset()
            {
                this._actual = Head;
            }

            public void Dispose()
            {
                
            }
        }


        public class Nodo
        {
            private T _value;
            private Nodo _nextNode;

            public T Value { get { return _value; } set { _value = value; } }
            public Nodo NextNode { get { return _nextNode; } set { _nextNode = value; } }

            public Nodo(T value, Nodo siguiente)
            {
                Value = value;
                NextNode = siguiente;
            }

            public override string ToString()
            {
                return "[" + Value + "] ";
            }
        }
    }


    
}