using NUnit.Framework;
using System.Collections.Generic;

namespace ListaEnlazada
{
    public class Tests
    {
        ListaEnlazada<int> lista = new ListaEnlazada<int>();

        [SetUp]
        public void Setup()
        {
            
        }

        [Test]
        public void Test1()

        {
            Assert.IsTrue(lista.A�adir(7));
            Assert.IsTrue(lista.A�adir(7));
            Assert.IsTrue(lista.A�adir(8));
            Assert.IsTrue(lista.A�adir(9));
            Assert.IsTrue(lista.A�adir(12));

            Assert.IsTrue(lista.Borrar(7));


            Assert.IsTrue(lista.Contiene(7));

            Assert.IsTrue(lista.GetElement(0).Equals(7));


            IEnumerator<int> iterador = lista.GetEnumerator();
            iterador.Reset();
            Assert.IsTrue(iterador.Current == 7);
            Assert.IsTrue(iterador.MoveNext());
            Assert.IsTrue(iterador.Current == 8);
            Assert.IsTrue(iterador.MoveNext());
            Assert.IsTrue(iterador.Current == 9);

        }
    }
}