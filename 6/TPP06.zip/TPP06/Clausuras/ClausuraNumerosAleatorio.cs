﻿
using System;

namespace Clausuras
{
    public static class ClausuraNumerosAleatorios
    {
        public static Func<int, int> CrearNumerosAleatorios(int rango, out Func<int> get)
        {
            //Se define el estado
            int _rango = rango;

            get =() => _rango;
            //Funciones a definir
            Random rand = new Random();


            return (_rango) => rand.Next(0,_rango);


        }
    }
}
