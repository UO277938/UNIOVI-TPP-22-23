﻿using System;
using System.Collections.Generic;
using System.Linq;
using Modelo;

namespace Ejercicio4
{
    internal class Program
    {
        private static Model modelo = new Model();
        static void Main()
        {
            ConsultaA();
            ConsultaB();
        }

        private static void ConsultaA()
        {


            var res = modelo.Employees.GroupBy(p => p.Office.Building, (o, b) => new
            {
                Oficina = b.Select(i => i.Office.Number),
                NombreOficina = o, 
                MediaEdad = b.Average(b => b.Age)
            });


            var e = res.Select(p => p.Oficina + ":" + p.NombreOficina + ":" + p.MediaEdad);

            Show(e);
        }

        private static void ConsultaB()
        {

        }

        private static void Show<T>(IEnumerable<T> colección)
        {
            foreach (var item in colección)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Elementos en la colección: {0}.", colección.Count());
        }
    }


}
