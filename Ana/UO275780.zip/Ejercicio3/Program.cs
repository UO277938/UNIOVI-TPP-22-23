﻿using System;

namespace Ejercicio3
{
    internal static class Program
    {
        static void Main()
        {
            
        }

        public static void Metodo<T>(T[] array, Action Current)
        {
            T valorActual = array[0];

            
            
        }

    }
}
