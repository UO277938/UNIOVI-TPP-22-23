﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    public class PilaSerie
    {
        private Pila _pila;

        private int _numero;

        public PilaSerie(uint numeroElementos)
        {
            _pila = new(numeroElementos);

#if DEBUG
            _pila.Invariante();
#endif
        }

        public Lista PopSerie(Predicate<object> condicion)
        {
            if(condicion == null)
            {
                throw new InvalidOperationException("No se puede pasar una condicion null");
            }

#if DEBUG
            _pila.Invariante();
            int contadorEliminar = 0;
#endif

            Lista devolver = new Lista();
            Lista añdir = new Lista();
            object aux = null;
            if (_numero == 0)
            {
                return devolver;
            } else
            {
                while(!_pila.EstaVacia)
                {
                    aux = _pila.Pop();

                    if (condicion(aux))
                    {
                        devolver.Añadir(aux);
#if DEBUG
                        contadorEliminar++;
#endif
                    }
                    else
                    {
                        añdir.Añadir(aux);
                    }
                }
            }

            if (_pila.EstaVacia)
            {
                PushSerie(añdir);
            }
#if DEBUG
            _pila.Invariante();
            Debug.Assert(devolver.NumeroElementos == _numero, "Hay una inconsistencia con la cantiada de elementos");
            Debug.Assert(devolver == null, "Hay una inconsistencia con la creacion del elemento");
#endif
            return devolver;
        }

        public int PushSerie(Lista elementos)
        {
            if (elementos == null)
            {
                throw new InvalidOperationException("No se puede pasar una condicion null");
            }

#if DEBUG
            _pila.Invariante();
#endif

            int cont = 0;
            if (_pila.EstaLlena)
            {
                return elementos.NumeroElementos;
            } else
            {
                
                for(int i = 0; i < elementos.NumeroElementos; i++)
                {
                    if (!_pila.EstaLlena)
                    {
                        _pila.Push(elementos.GetElemento(i));
                        cont++;
                        _numero++;
                    }
                }
            }

#if DEBUG
            _pila.Invariante();
            
#endif

            return elementos.NumeroElementos - cont;
        }
    }
}
